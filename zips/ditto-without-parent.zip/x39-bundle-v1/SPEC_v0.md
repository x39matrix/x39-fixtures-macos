# X-39 Bundle Verifier — Format Specification v0

This describes the current `verify_bundle.py` implementation, not a proposed schema. Source references are line numbers in the included `verify_bundle.py`.

## Container and fields

Input is a ZIP. It must contain `proof.json`, `proof.json.ots`, and `signatures.json`; other entries are accepted (72–84). Each JSON file must decode as UTF-8 to an object (87–94).

The verifier reads these `proof.json` fields: `agreement_id`, `content_hash`, `sealed_at`, `v`, `files`, `chat_merkle_root`, `msg_sigs`, `sig_keys`, and `title` (106–110, 232–240, 243–317, 339–356, 383–394). There is no closed proof schema or general type validator. Fields are optional unless a selected verification path requires them. For versions `X39-NOTARIA-2` and `X39-NOTARIA-3`, `chat_chain.json` is required. `files`, when present, is a name-to-SHA256 map of ZIP entries (339–356).

`signatures.json` supplies `proof_hash`, optional cross-fields (`agreement_id`, `content_hash`, `sealed_at`), and optional `cold` and `warm` signature blocks (97–110, 197–229). Each ML-DSA block uses `algorithm`, `public_key_b64`, `signature_b64`, and optionally `fingerprint` (154–194). The COLD key fingerprint must be in the verifier's pinned set; WARM is informational and does not affect the result (57–60, 204–229).

Fixed lengths: ML-DSA-87 public key 2,592 bytes and signature 4,627 bytes (34–35, 167–171). Ed25519 public keys in `sig_keys` are 32 bytes and message signatures are 64 bytes (280–305).

For chat-chain v2/v3, entries use `prev_hash`, `role`, `content_hash`, `ts`, and `msg_hash`; v3 signed entries also use `cts` and `sig_b64` (243–271, 274–317). A chat-chain message signature covers `x39msg:v3:<agreement_id>:<content_hash>:<cts>`.

## Verification order

1. Open ZIP and check required member names; read all members (72–84).
2. Parse `proof.json`; check optional `proof.files` manifest (368–371).
3. If `--content` was supplied, compare its SHA-256 to `content_hash` (232–240, 372).
4. For v2/v3, recompute chat hashes and chain tip; verify Ed25519 message signatures and counters (243–317, 373–374).
5. Parse `signatures.json`; compare raw `proof.json` SHA-256 to `signatures.json.proof_hash`; compare cross-fields; verify COLD pin and ML-DSA signature, and perform an altered-signature negative control. WARM is advisory (97–103, 106–110, 131–229, 375).
6. Run `ots verify` unless `--skip-ots` (320–336, 376–377). Then print `VALID` and coverage notes (378–414).

## Failures and exit codes

`die()` prints `FAIL[<code>]: <message>` to stderr (67–69). Relevant behavior:

- **1, integrity:** missing/wrong `proof_hash` → `proof_hash mal formado en signatures.json` or `proof_hash mismatch: claimed=... recomputed=...` (97–103); malformed JSON → `<label> no es JSON UTF-8 valido: ...` (87–94); chain, content, or manifest mismatch reports its field/index and mismatch reason (232–271, 339–356).
- **2, signature:** wrong ML-DSA length → `<label>: tamano N bytes, esperado M`; untrusted COLD key → `<label>: clave NO reconocida...`; invalid signature → `<label>: ML-DSA-87.verify FALLO` (113–128, 164–194). Ed25519 problems report missing key, length, or `firma Ed25519 INVALIDA` (280–310).
- **3, OTS:** timeout → `ots verify timeout (120s)`; nonzero `ots` result → `ots verify fallo: ...` (320–336).
- **4, input/dependency:** missing ZIP member → `ZIP incompleto, faltan: [...]`; malformed ZIP → `ZIP invalido: ...`; missing `ots`, `pqcrypto`, or `cryptography` reports an install message (72–94, 131–151, 283–286, 320–336).

The code does not prove that signed or timestamped content is factually true. `--skip-ots` deliberately omits Bitcoin verification (363, 376–377, 398–409).
