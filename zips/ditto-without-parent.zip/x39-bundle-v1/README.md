# X-39 Evidence Bundle v1

This folder contains public verification material for one X-39 agreement and one Sevilla municipal document. It contains no private keys or seeds. The agreement JSON and OTS proof were fetched from the public API; the API's downloadable ZIP supplies the signature and chat-chain files required by the repository verifier.

## Files

- `31e1cf09a5b2a74cd978.json`: public agreement proof body (`proof.json` inside the API ZIP).
- `31e1cf09a5b2a74cd978.ots`: OpenTimestamps proof for those exact JSON bytes.
- `31e1cf09a5b2a74cd978.zip`: original public evidence ZIP. It contains `proof.json`, `proof.json.ots`, `signatures.json`, `chat_chain.json`, and an informational README. The verifier reports that README as uncovered; do not treat it as signed evidence.
- `signatures.json`: `proof_hash`, public COLD ML-DSA-87 key and signature, fixed fingerprint, and agreement metadata.
- `chat_chain.json`: public message-chain entries verified by the program.
- `COLD_FINGERPRINT.txt`: the 64-hex COLD public-key fingerprint pinned in `verify_bundle.py`. The corresponding public key is in `signatures.json`.
- `2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf` and its `.ots`, `.tsr`, and `.fuente.txt`: the Sevilla showcase document, OpenTimestamps proof, RFC 3161 timestamp response, and source note.
- `verify_bundle.py`: byte-for-byte copy of the repository verifier used for this check.
- `SPEC_v0.md`: concise description of the verifier's current format and behavior, with source line references.
- `MANIFEST`: SHA-256 for each other regular file in this folder. It excludes itself because a file cannot contain its own final hash.

## Check the downloaded agreement bytes

Run these commands from this directory:

```sh
sha256sum 31e1cf09a5b2a74cd978.json 31e1cf09a5b2a74cd978.ots
python3 - <<'PY'
import hashlib, json
from pathlib import Path
proof = Path('31e1cf09a5b2a74cd978.json').read_bytes()
sigs = json.loads(Path('signatures.json').read_text())
actual = hashlib.sha256(proof).hexdigest()
print('sha256:', actual)
print('signatures.json proof_hash:', sigs['proof_hash'])
assert actual == sigs['proof_hash']
PY
```

Expected JSON SHA-256 and `proof_hash`: `7e897e5b6a8dcdd2ef2a8411365e02e88c9f58407fd84e14f6fdefa5c2a32cf6`. Expected OTS SHA-256: `4b396c8bc6c4b023c6adfaf9e8af613c6331684fa96cc7a0017c3e7ef8ead8f3`. The standalone JSON does **not** carry `proof_hash`; that field is in `signatures.json`. The JSON and OTS bytes are identical to the corresponding members in the API ZIP.

## Verify the agreement offline

Requirements: Python 3, `cryptography`, `pqcrypto` with ML-DSA-87, and `zipfile` from the Python standard library. Check the copy and package hashes first:

```sh
sha256sum -c MANIFEST
python3 verify_bundle.py 31e1cf09a5b2a74cd978.zip --skip-ots
```

Expected: `VALID (OTS omitido)`, the pinned COLD co-signature is valid, the chat chain and 7/7 Ed25519 message signatures validate, and `proof.json.ots` is explicitly listed as omitted. This offline command was run successfully on this bundle.

The verifier rejects a changed proof byte: `FAIL[1]: proof_hash mismatch` for a syntactically valid JSON edit. A byte change that makes invalid JSON fails earlier with `FAIL[1]: proof.json no es JSON UTF-8 valido: ...`. The valid-JSON negative test was run on a temporary archive and did not alter this bundle.

The public pin is `8453a25a41d6fe8fcb5647600f042a7c303daaca79b80928534025711981c6a1`; it appears in `verify_bundle.py` at line 59. Key and signature lengths are checked by the verifier: ML-DSA-87 public key 2,592 bytes and signature 4,627 bytes. This bundle's `signatures.json` has exactly those lengths.

## Timestamp clocks and network checks

There are distinct time claims:

1. `proof.json.sealed_at` is the notary's recorded time. The verifier prints it as informational; it is not an independently trusted clock.
2. The `.ots` proof commits the JSON hash into Bitcoin. The Bitcoin block attestation supplies the external time evidence once checked against Bitcoin's chain.

The Sevilla `.tsr` is a separate RFC 3161 timestamp response. Its parsed message imprint matches the PDF hash. This check did not validate the TSA certificate chain, and the source note is not itself a cryptographic attestation.

`ots info` is an offline inspection, not a full Bitcoin verification. Full `ots verify` needs access to Bitcoin data. For an independent, third-party-free check, use your own Bitcoin node with the verifier's `--bitcoin-node` option. As an online alternative, submit the public `proof.json` and `.ots` to `https://opentimestamps.org`; that relies on the external service. `--skip-ots` verifies the JSON, chain, and signatures but does not establish Bitcoin inclusion or block time.

## Check the Sevilla document sidecars

```sh
sha256sum 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf
ots info 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf.ots
openssl ts -reply -in 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf.tsr -text
```

Expected PDF SHA-256: `fbc3f576bc346529acc9c54073b409ea171fff6f042d3732b223b7005146f1ca`. The OTS file's committed SHA-256 and the RFC 3161 message imprint match it. `ots info` shows Bitcoin block attestations, but these were not checked against a node here. OpenSSL parses the timestamp response; no trusted TSA certificate was supplied for a full signature-chain check.

## Scope and limits

A valid digital signature shows that the corresponding key signed those bytes; a timestamp shows that a commitment to those bytes existed no later than the validated timestamp. Neither proves that the agreement or municipal document is true, lawful, complete, or performed. The agreement JSON, Sevilla document, and their timestamps are separate evidence objects: the Sevilla PDF is not the agreement's `content_hash`. The `.fuente.txt` records a claimed source URL and freeze time; it is not signed by the cited municipality. The verifier's COLD fingerprint is a trust anchor only if the reader independently trusts that pin.


### TSA certificate-chain verification

The bundled timestamp response (`.tsr`) was verified against the bundled acta PDF using the bundled ANF root and untrusted intermediate certificate. Run:

```sh
openssl ts -verify -in 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf.tsr \
  -data 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf \
  -CAfile anf_root.pem \
  -untrusted 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf.cadena.pem
```

Expected final line: `Verification: OK`. This chain produced that result. OpenSSL also warned that the timestamping-unit certificate supplied as untrusted is not a CA certificate; it is used as a certificate in the chain, not as a CA.

Inspect every certificate's subject and issuer with OpenSSL. The chain PEM contains the timestamping-unit certificate followed by its issuing intermediate:

```sh
openssl x509 -in anf_root.pem -noout -subject -issuer
awk '/-----BEGIN CERTIFICATE-----/ { n++; out=sprintf("/tmp/anf-chain-%d.pem", n) } out != "" { print > out } /-----END CERTIFICATE-----/ { close(out); out="" }' 2O-ACTA-DEL-PLENO-MUNICIPAL-EXTRAORDINARIO-PRESUPUESTO-2026-01-29.pdf.cadena.pem
for cert in /tmp/anf-chain-*.pem; do openssl x509 -in "$cert" -noout -subject -issuer; done
```

The observed links are: the TSU certificate (1383) is issued by `ANF AC Qualified TSA`; that intermediate is issued by `ANF Global Root CA`; the root is self-issued. A valid timestamp signature and certificate chain establish that the TSA signed a timestamp response for the PDF imprint and that the response verifies to the supplied root. The timestamp does **not** establish that the PDF's contents are true or accurate.
